#' \packageDescription{afex}
#'
#' The DESCRIPTION file:
#' \packageDESCRIPTION{afex}
#'
#' @title
#' \packageTitle{afex}
#'
"_PACKAGE"
