#' \packageDescription{afex}
#'
#' The DESCRIPTION file:
#' \packageDESCRIPTION{afex}
#'
#' @title
#' \packageTitle{afex}
#'
#' Maintainer: \packageMaintainer{afex}
"_PACKAGE"
